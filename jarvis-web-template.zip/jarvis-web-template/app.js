const $ = (id) => document.getElementById(id);
const logEl = $("log");
const statusText = $("statusText");
const warnBox = $("warnBox");

const state = {
  speaking: true,
  mode: "AURORA",
  core: "IDLE",
  link: "LOCAL",
  notes: loadNotes(),
};

function stamp(){ return new Date().toLocaleString(); }

function setStatus(text, core){
  statusText.textContent = text;
  if(core) state.core = core;
  $("coreState").textContent = state.core;
  $("modeState").textContent = state.mode;
  $("linkState").textContent = state.link;
}

function escapeHtml(str){
  return str.replace(/[&<>"']/g, (m)=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[m]));
}

function addMsg(role, text){
  const wrap = document.createElement("div");
  wrap.className = "msg " + role;
  wrap.innerHTML = `
    <div class="meta">${role === "user" ? "YOU" : "JARVIS"} • ${stamp()}</div>
    <div class="body">${escapeHtml(text)}</div>
  `;
  logEl.prepend(wrap);
}

function speak(text){
  if(!state.speaking) return;
  if(!("speechSynthesis" in window)) return;
  try{
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.02;
    window.speechSynthesis.speak(u);
  }catch(e){}
}

function jarvis(text){
  addMsg("jarvis", text);
  speak(text);
}

function renderChips(){
  const chips = ["help","time","dashboard","note buy milk","notes","export notes","mode stealth","status","clear"];
  const wrap = $("chips");
  wrap.innerHTML = "";
  chips.forEach(c=>{
    const b = document.createElement("button");
    b.className = "chip";
    b.textContent = c;
    b.onclick = ()=> runCommand(c);
    wrap.appendChild(b);
  });
}

function renderDashboard(){
  $("timeNow").textContent = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
  $("dateNow").textContent = new Date().toLocaleDateString([], {weekday:"short", year:"numeric", month:"short", day:"numeric"});
  $("noteCount").textContent = String(state.notes.length);

  const sysOptions = [
    ["Nominal","All subsystems stable"],
    ["Elevated","Sensor sweep running"],
    ["Optimized","Cache warmed • 98% hit rate"],
    ["Alert","External noise detected (demo)"]
  ];
  const pick = sysOptions[Math.floor(Math.random()*sysOptions.length)];
  $("sysStat").textContent = pick[0];
  $("sysDetail").textContent = pick[1];

  const grid = $("chartGrid");
  grid.innerHTML = "";
  const n = 22;
  for(let i=0;i<n;i++){
    const bar = document.createElement("div");
    bar.className = "bar";
    const h = 10 + Math.floor(Math.random()*78);
    bar.style.left = (6 + i*(100/n)) + "%";
    bar.style.height = h + "px";
    grid.appendChild(bar);
  }
}

function renderNotes(){
  const list = $("notesList");
  list.innerHTML = "";
  if(state.notes.length === 0){
    const empty = document.createElement("div");
    empty.className = "note";
    empty.innerHTML = `<div class="note-body muted">No notes yet. Say: <b>note ...</b></div>`;
    list.appendChild(empty);
    return;
  }
  state.notes.slice().reverse().forEach(n=>{
    const item = document.createElement("div");
    item.className = "note";
    item.innerHTML = `
      <div class="note-top"><b>Note</b><div class="note-time">${n.t}</div></div>
      <div class="note-body">${escapeHtml(n.text)}</div>
    `;
    list.appendChild(item);
  });
}

function saveNotes(){ localStorage.setItem("jarvis_notes", JSON.stringify(state.notes)); }
function loadNotes(){
  try{
    const raw = localStorage.getItem("jarvis_notes");
    return raw ? JSON.parse(raw) : [];
  }catch(e){ return []; }
}

function showWarn(msg){ warnBox.style.display = "block"; warnBox.textContent = msg; }
function hideWarn(){ warnBox.style.display = "none"; warnBox.textContent = ""; }

function runCommand(input){
  const cmd = (input || "").trim();
  if(!cmd) return;
  $("inputCmd").value = "";
  addMsg("user", cmd);
  setStatus("Processing…", "ACTIVE");

  const lower = cmd.toLowerCase();

  if(lower === "help" || lower === "commands"){
    jarvis("Commands: help, time, date, dashboard, status, note <text>, notes, erase notes, export notes, mode <name>, voice on/off, clear.");
    setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "time"){
    jarvis("The current time is " + new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}) + ".");
    renderDashboard(); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "date"){
    jarvis("Today is " + new Date().toLocaleDateString([], {weekday:"long", year:"numeric", month:"long", day:"numeric"}) + ".");
    renderDashboard(); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "status"){
    jarvis(`Core: ${state.core}. Mode: ${state.mode}. Link: ${state.link}. Notes: ${state.notes.length}.`);
    renderDashboard(); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "voice on"){
    state.speaking = true; $("btnSpeak").textContent = "Voice: ON";
    jarvis("Voice output enabled."); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "voice off"){
    state.speaking = false; $("btnSpeak").textContent = "Voice: OFF";
    addMsg("jarvis", "Voice output disabled."); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower.startsWith("mode ")){
    const m = cmd.slice(5).trim();
    state.mode = m ? m.toUpperCase() : "AURORA";
    $("modeState").textContent = state.mode;
    jarvis("Mode set to " + state.mode + ".");
    setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "dashboard"){
    $("dashboard").scrollIntoView({behavior:"smooth"});
    jarvis("Opening dashboard."); renderDashboard(); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "notes"){
    $("notes").scrollIntoView({behavior:"smooth"});
    jarvis("Opening notes."); renderNotes(); renderDashboard(); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower.startsWith("note ")){
    const text = cmd.slice(5).trim();
    if(!text){ jarvis("Please provide note content. Example: note buy milk."); setStatus("Standing by.", "IDLE"); return; }
    state.notes.push({t: stamp(), text}); saveNotes(); renderNotes(); renderDashboard();
    jarvis("Note saved."); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "erase notes" || lower === "clear notes"){
    state.notes = []; saveNotes(); renderNotes(); renderDashboard();
    jarvis("All notes erased."); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "export notes"){
    const blob = new Blob([JSON.stringify(state.notes, null, 2)], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "jarvis-notes.json";
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    jarvis("Exported notes as jarvis-notes.json."); setStatus("Standing by.", "IDLE"); return;
  }
  if(lower === "clear"){
    logEl.innerHTML = "";
    jarvis("Console cleared."); setStatus("Standing by.", "IDLE"); return;
  }

  jarvis("I did not recognize that command. Say 'help' to see available commands.");
  setStatus("Standing by.", "IDLE");
}

// Voice input
let recognition = null;
function setupVoice(){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SR){
    showWarn("Voice recognition is not supported on this browser/device. Use typing instead. (Voice output may still work.)");
    $("btnMic").disabled = true;
    return;
  }
  recognition = new SR();
  recognition.lang = "en-US";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.onstart = ()=> setStatus("Listening…", "LISTEN");
  recognition.onend = ()=> setStatus("Standing by.", "IDLE");
  recognition.onerror = (e)=> {
    setStatus("Standing by.", "IDLE");
    showWarn("Mic error: " + (e.error || "unknown") + ". Try again or use typing.");
  };
  recognition.onresult = (event)=>{
    const text = event.results[0][0].transcript;
    runCommand(text);
  };
}

function wake(){
  hideWarn();
  setStatus("Awaiting command.", "READY");
  jarvis("At your service.");
}

function bindUI(){
  $("btnWake").onclick = wake;
  $("btnHelp").onclick = ()=> runCommand("help");
  $("btnRefresh").onclick = ()=> { renderDashboard(); toast("Dashboard refreshed"); };
  $("btnClear").onclick = ()=> runCommand("clear");
  $("btnErase").onclick = ()=> runCommand("erase notes");
  $("btnExport").onclick = ()=> runCommand("export notes");
  $("btnRun").onclick = ()=> runCommand($("inputCmd").value);
  $("inputCmd").addEventListener("keydown", (e)=>{ if(e.key === "Enter") runCommand($("inputCmd").value); });

  $("btnSpeak").onclick = ()=>{
    state.speaking = !state.speaking;
    $("btnSpeak").textContent = "Voice: " + (state.speaking ? "ON" : "OFF");
    toast("Voice " + (state.speaking ? "enabled" : "disabled"));
    if(state.speaking) speak("Voice enabled.");
  };

  $("btnMic").onclick = ()=>{
    if(!recognition) return;
    hideWarn();
    try{ recognition.start(); }catch(e){}
  };

  window.addEventListener("keydown", (e)=>{
    if(e.key.toLowerCase() === "k" && (e.ctrlKey || e.metaKey)){
      e.preventDefault(); $("inputCmd").focus();
    }
    if(e.key.toLowerCase() === "j" && (e.ctrlKey || e.metaKey)){
      e.preventDefault(); wake();
    }
  });
}

let toastTimer = null;
function toast(msg){
  let el = document.getElementById("toast");
  if(!el){
    el = document.createElement("div");
    el.id = "toast";
    Object.assign(el.style,{
      position:"fixed", left:"50%", bottom:"22px", transform:"translateX(-50%)",
      padding:"12px 14px", borderRadius:"14px",
      background:"rgba(0,0,0,.72)", border:"1px solid rgba(255,255,255,.12)",
      backdropFilter:"blur(12px)", color:"#e9f3ff",
      fontWeight:"800", fontSize:"13px",
      opacity:"0", transition:"opacity .15s ease",
      zIndex:"9999"
    });
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.style.opacity = "1";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=> el.style.opacity="0", 1200);
}

// Init
renderChips();
renderNotes();
renderDashboard();
bindUI();
setupVoice();
jarvis("Systems online. Say 'help' for commands.");
setStatus("Standing by.", "IDLE");
