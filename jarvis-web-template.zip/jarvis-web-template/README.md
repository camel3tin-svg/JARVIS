# JARVIS Web (Demo)

Static JARVIS-style assistant (UI demo) for GitHub Pages.

## Files
- index.html
- style.css
- app.js

## Deploy (GitHub Pages)
1) Upload these files to your repo (e.g. `JARVIS`)
2) Settings → Pages → Deploy from a branch → main → /(root)
3) Open: https://YOURUSERNAME.github.io/JARVIS/

## Notes
- Voice output uses speechSynthesis (TTS)
- Voice input uses Web Speech API (SpeechRecognition). Often NOT supported on iPhone Safari.
